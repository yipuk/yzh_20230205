
"""I worked out the calculation of the number of all combinations.
However, I haven't got enough time to work out how to calculate the number of odd combinations.
I feel the key point is that the odd number of combinations for the current amount equals to
the even number of combinations from its previous amount plus one. The even and odd numbers are
added to the number of all combinations."""


# coins with face values of 1 pence, 2, 5, 10, 20, 50 pences, 1 and 2 pounds
COINS = [1, 2, 5, 10, 20, 50, 100, 200]
N = len(COINS)


def convert_amount_string_to_interger(amount_string):
    try:
        amount_string = amount_string.replace('£', '')
        amount_list = amount_string.split('-')
        if amount_list[1] == '':
            amount_list[1] = '0'
        if len(amount_list[1]) <= 2:
            return int(amount_list[0]) * 100 + int(amount_list[1])
    except:
        raise ValueError("The input string must be in the format of £{pound}-{pence}.")


def coin_machine_all_combinations(amount_string):

    amount = convert_amount_string_to_interger(amount_string)

    count = [1] + [0] * amount
    for i in range(N-1, -1, -1):
        next_count = [1] + [0] * amount

        for j in range(1, amount + 1):
            next_count[j] = count[j]
            if j - COINS[i] >= 0:
                next_count[j] += next_count[j - COINS[i]]

        count = next_count

    return count[amount]


x = "£0-11"
z = coin_machine_all_combinations(x)
print(z)