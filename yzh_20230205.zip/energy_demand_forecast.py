
import datetime
import logging
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from scipy.optimize import curve_fit
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics import tsaplots
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.formula.api import ols


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def plot_ts(x, y, title, xlabel, ylabel, path, **kwargs):
    fig, ax = plt.subplots()
    ax.plot(x, y, **kwargs)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.grid(linestyle='--')
    plt.savefig(path)
    plt.close()


def cosine_func(x, a0, a1, a2, a3):
    return a0*np.cos(a1*x + a2) + a3


class EnergyConsumptionModel(object):
    """
    We use cosine function and weekday effects as the seasonal components and the ARIMA(p,d,q) component to
    build a model for the energy consumption data.
    """
    def __init__(self, data_path, figure_path):
        self.data_path = data_path
        self.figure_path = figure_path
        self.params_format='(p,d,q)'
        self.fitted_value_colname = 'Arima Fitted Value'
        self.rolling_window_size = 300
        self.forecast_step = 364
        self.fit_arima_models_summary = None
        self.cosine_params = None
        self.model_data = None
        self.weekday_coef_df = None
        self.forecast_df = None
        logger.info(f'Autoregressive integrated moving average model (ARIMA) in the format of {self.params_format} '
                    'with seasonal factors is employed to model the energy consumption.\n'
                    'p is the parameter of the autoregressive term.\n'
                    'd is the parameter of the differencing term.\n'
                    'q is the parameter of the moving average term.\n'
                    'From the following analyiss, we can see that the cosine function model plays the main role.\n'
                    'The choice of ARIMA model does not have a large impact.\n'
                    f'All figures generated in the modelling process are saved into {self.figure_path}. \n')

    @property
    def raw_data(self):
        df = pd.read_table(self.data_path, sep=",", parse_dates=['Date'])
        df['Time'] = df.index
        df['Weekday'] = [str(value.weekday()) for value in df['Date'].tolist()]
        return df

    @property
    def dates(self):
        """All dates in the raw data"""
        return self.raw_data['Date'].values

    @property
    def cosine_time(self):
        """Time expressed in the number of days starting from 0"""
        return self.raw_data['Time'].values

    @property
    def consumption_data(self):
        """Energy consumption raw data"""
        return self.raw_data['Consumption'].values

    @property
    def n(self):
        """The number of raw data points."""
        return self.raw_data.shape[0]

    @property
    def start_date(self):
        """start date of the raw data"""
        return min(self.raw_data['Date']).date()

    @property
    def end_date(self):
        """end date of the raw data"""
        return max(self.raw_data['Date']).date()

    @property
    def cosine_fitted_consumption(self):
        """fitted values of energy consumption from the cosine function model"""
        if self.cosine_params is not None:
            return cosine_func(self.cosine_time, *self.cosine_params)
        else:
            logger.error('Cosine function has not been fit!')
            return None

    @property
    def cosine_residuals(self):
        """cosine fit residuals calculated by using the consumption value minus its fitted value"""
        return self.consumption_data - self.cosine_fitted_consumption

    @property
    def fitted_arima_model(self):
        """The best fit model of the seasonal residuals"""
        # choose the fitted model as the one with the smallest AIC value.
        if self.fit_arima_models_summary is not None:
            param = self.fit_arima_models_summary[self.params_format][0]
            return ARIMA(
                self.model_data['Seasonal Residuals'].values,
                order=(param[0], param[1], param[2])).fit()
        else:
            logger.error('The fit_models method needs to be called to obtain the fitted model.')
            return None

    def run(self):
        # draw the time series plot of the energy consumption to observe the trend
        self._plot_consumption_data()
        # fit a cosine function model to the energy consumption
        self.fit_cosine_model()
        # fit a weekday categorical linear model to the cosine fit residuals and results in a seasonal residuals
        self.fit_categorical_linear_model()
        # draw time sereis plots of the seasonal residuals to decide how to build the model
        self._plot_seasonal_residuals()
        # self._plot_hist_seasonal_residuals()
        # check the stationarity of the 1st difference of the seasonal residuals
        self._check_stationary()
        # draw acf and pacf plots for the 1st difference of the seasonal residuals
        self._plot_acf()
        self._plot_pacf()
        # According to the analysis of ACF and PACF plots, we could try ARIMA(p,d,q) with parameter values of
        # p=[1,2], d=1, q=[1,2], or 3 to fit the seasonal residuals
        d = 1
        parameter_list = [
            [0, d, 1], [0, d, 2], [0, d, 3],
            [1, d, 0], [1, d, 1], [1, d, 2], [1, d, 3],
            [2, d, 0], [2, d, 1], [2, d, 2], [2, d, 3],
            [3, d, 0], [3, d, 1], [3, d, 2], [3, d, 3]
        ]
        self.fit_arima_models(parameter_list=parameter_list)
        # produce model diagnosis plots for the best fitted arima model
        self.diagnose_arima_model()
        # the final model = cosine function model + weekday categorical model + best fit arima model
        # calculate the fitted consumption under the final model
        self.calculate_fitted_consumption()
        # calculate the 1-year ahead consumption under the final model
        self.calculate_forecast_consumption()
        # draw fitted consumption plot under the final model to see if the fit is good
        self._plot_fitted_consumption()
        # draw forecast consumption plot under the final model
        self._plot_forecast_consumption()

    def diagnose_arima_model(self, size=(15, 12)):
        # give model fit summary
        logger.info(f'The best fit ARIMA model summary: \n {self.fitted_arima_model.summary()} \n.')
        logger.info(f' Ljung_Box statistic is large enough to suggest there is no correlation in residuals.\n')
        # produce model diagnosis plots.
        fig_path = self.figure_path + 'arima_model_diagnosis.png'
        self.fitted_arima_model.plot_diagnostics(figsize=size)
        plt.grid(linestyle='--')
        plt.savefig(fig_path)
        plt.close()
        logger.info(f'Model diagnosis plots are saved into {fig_path}.\n')
        logger.info('Standardized residuals looks like white noise.\n'
                    'Histogram of residuals roughly follows a standard normal distribution.\n'
                    'Q-Q plot also indicates residuals roughly follows a standard normal distribution.\n'
                    'ACF of residuals looks reasonable.')
        logger.info('Hence, the fitted model is adequate.')

    def _plot_fitted_consumption(self):
        fig_path=self.figure_path + 'ts_fitted_consumption.png'
        fig, ax = plt.subplots()
        ax.plot(self.dates, self.model_data['Fitted Consumption'].values, color='red', linestyle='--')
        ax.plot(self.dates, self.consumption_data, linestyle=':')
        ax.set_title(f'Energy Consumption Fitted vs. Actual')
        ax.set_xlabel('Year')
        ax.set_ylabel('Energy Consumption')
        ax.legend(['fitted', 'actual'])
        ax.grid(linestyle='--')
        plt.savefig(fig_path)
        plt.close()
        logger.info(f'Energy fitted consumption time series plot is saved into {self.figure_path}.\n'
                    'Fitted consumption looks similar to the actual values, which demonstrates the model is adequate.\n')

    def _plot_forecast_consumption(self):
        fig_path = self.figure_path + 'ts_forecast_consumption.png'
        plot_ts(
            self.forecast_df['Date'].values,
            self.forecast_df['Forecast Consumption'].values,
            title=f'One-year Ahead Energy Consumption Forecast',
            xlabel='Year',
            ylabel='',
            path=fig_path,
        )
        logger.info(f'Energy consumption forecast time series plot is saved into {fig_path}.\n')

    def calculate_fitted_consumption(self):
        self.model_data['Fitted Seasonal Residuals'] = self.fitted_arima_model.fittedvalues
        self.model_data['Fitted Consumption'] = \
            self.model_data['Fitted Seasonal Residuals'] + self.model_data['Weekday Coef'] + self.model_data['Cosine Fitted Consumption']

    def calculate_forecast_consumption(self):
        self.forecast_df = pd.DataFrame({
            'Date': pd.date_range(self.end_date + datetime.timedelta(1), self.end_date + datetime.timedelta(self.forecast_step)),
        })
        self.forecast_df['Time'] = self.forecast_df.index
        self.forecast_df['Time'] += self.cosine_time[-1] + 1
        self.forecast_df['Weekday'] = [str(value.weekday()) for value in self.forecast_df['Date'].tolist()]

        self.forecast_df = pd.merge(self.forecast_df, self.weekday_coef_df, how='left', on=['Weekday', 'Weekday'])
        self.forecast_df['Cosine Forecast Consumption'] = cosine_func(self.forecast_df['Time'], *self.cosine_params)
        self.forecast_df['ARIMA Forecast Consumption'] = \
            self.fitted_arima_model.predict(
                start=self.forecast_df['Time'].values[0],
                end=self.forecast_df['Time'].values[-1])
        self.forecast_df['Forecast Consumption'] =  \
            self.forecast_df['ARIMA Forecast Consumption'] + self.forecast_df['Cosine Forecast Consumption'] \
            + self.forecast_df['Weekday Coef']

    def fit_categorical_linear_model(self):
        """  fit the consumption data with a weekday categorical linear model.
        lower case and simple column names matters, so have to create a data copy."""
        data = self.model_data.copy()
        data['residuals'] = data['Cosine Residuals']
        data['weekday'] = data['Weekday']

        lm_model = ols('residuals ~ C(weekday) - 1', data=data)
        fitted_model = lm_model.fit()
        logger.info(f'Weekday categorical linear model fit summary: \n {fitted_model.summary()}\n')
        self.weekday_coef_df = pd.DataFrame({'Weekday': ['0', '1', '2', '3', '4', '5', '6'],
                                             'Weekday Coef': list(fitted_model.params)})
        self.model_data = pd.merge(self.model_data, self.weekday_coef_df, how='left', on=['Weekday', 'Weekday'])
        self.model_data['Seasonal Residuals'] = self.model_data['Cosine Residuals'] - self.model_data['Weekday Coef']
        logger.info('The weekday categorical linear model is fit to the energy consumption cosine fit residuals.\n'
                    'The seasonal residuals from the weekday categorical linear model will be used to build ARIMA '
                    'models.\n')

    def fit_cosine_model(self):
        """fit the consumption data with the cosine function model."""
        a0 = max(self.consumption_data) - min(self.consumption_data)

        sample_freq = np.fft.fftfreq(self.n, 1.0)
        fourier_transform = abs(np.fft.fft(self.consumption_data))
        freq = abs(sample_freq[np.argmax(fourier_transform[1:]) + 1])
        a1 = 2 * np.pi * freq
        a2 = 0.0
        a3 = np.mean(self.consumption_data)

        self.cosine_params, _ = curve_fit(
            cosine_func, self.cosine_time, self.consumption_data,
            p0=[a0, a1, a2, a3])
        logger.info('The cosine function model is fit to the energy consumption.\n'
                    'The cosine fit residuals will be carried over to build other components.\n')

        self.model_data = self.raw_data
        self.model_data['Cosine Residuals'] = self.cosine_residuals
        self.model_data['Cosine Fitted Consumption'] = self.cosine_fitted_consumption
        self._plot_cosine_fitted_consumption()
        self._plot_cosine_residuals()

    def fit_arima_models(self, parameter_list):
        res = []
        for param in parameter_list:
            try:
                model = ARIMA(
                    self.model_data['Seasonal Residuals'].values,
                    order=(param[0], param[1], param[2])).fit()
            except:
                continue
            aic = model.aic
            res.append([param, aic])

        res_df = pd.DataFrame(res)
        res_df.columns = [self.params_format, 'AIC']
        # sort with an ascending order of AIC. The lower AIC, the better.
        res_df = res_df.sort_values(by='AIC', ascending=True).reset_index(drop=True)
        self.fit_arima_models_summary = res_df
        logger.info('All ARIMA models are fitted to the seasonal residuals.')

    def _check_stationary(self):
        pvalue = adfuller(self.model_data['Seasonal Residuals'].diff()[1:])[1]
        logger.info(f'Augumented Dickey Fuller test p-value={pvalue} \n'
                    f'The small p-value suggests the seasonal residuals 1st difference is stationary. \n')
        logger.info('The evidence is sufficient to show the 1st difference of the seasonal residuals '
                    'is stationary. Thus, we could use it to build ARMA model.\n')

    def _plot_consumption_data(self):
        fig_path = self.figure_path + 'ts_consumption.png'
        plot_ts(
            self.dates,
            self.consumption_data,
            title='Energy Consumption 5-year Time Series',
            xlabel='Year',
            ylabel='Energy Consumption',
            path=fig_path
        )
        logger.info(f'Energy consumption time series plot is saved into {fig_path}.\n'
                    'The seasonal trend of the energy consumption data suggests'
                    'that a cosine function model would be a good fit.\n')

    def _plot_cosine_fitted_consumption(self):
        fig_path=self.figure_path + 'ts_cosine_fitted_consumption.png'
        fig, ax = plt.subplots()
        ax.plot(self.dates, self.consumption_data, linestyle=':')
        ax.plot(self.dates, self.cosine_fitted_consumption, color='red', linestyle='--', linewidth=3)
        ax.set_title('Cosine Fitted Value vs. Actual Value for Energy Consumption')
        ax.set_xlabel('Year')
        ax.legend(['actual value', 'cosine fitted value'])
        ax.grid(linestyle='--')
        plt.savefig(fig_path)
        plt.close()
        logger.info(f'Cosine fitted value plot is saved into {fig_path}.\n'
                    'The cosine function seems to have a reasonable fit of the energy consumption.\n')

    def _plot_cosine_residuals(self):
        fig_path = self.figure_path + 'ts_cosine_residuals.png'
        plot_ts(
            self.dates,
            self.cosine_residuals,
            title='Energy Consumption Cosine Fit Residuals',
            xlabel='Year',
            ylabel='Consumption Cosine Residuals',
            path=fig_path
        )
        logger.info(f'Time series plot of energy consumption cosine fit residuals is saved into {fig_path}.\n'
                    'Cosine fit residuals do not seem to be stationary.\n')

    def _plot_seasonal_residuals(self):
        fig_path = self.figure_path + 'ts_seasonal_residuals.png'
        plot_ts(
            self.dates,
            self.model_data['Seasonal Residuals'].values,
            title='Energy Consumption Seasonal Residuals',
            xlabel='Year',
            ylabel='',
            path=fig_path
        )
        logger.info(f'Time series plot of energy consumption seasonal residuals is saved into {fig_path}.\n'
                    'The energy consumption seasonal residuals time series do not look stationary. Thus, '
                    'we consider to model its 1st difference.\n')

        fig_path = self.figure_path + 'ts_seasonal_residuals_diff.png'
        plot_ts(
            self.dates[1:],
            self.model_data['Seasonal Residuals'].diff().values[1:],
            title='Energy Consumption Seasonal Residuals 1st Difference',
            xlabel='Year',
            ylabel='',
            path=fig_path
        )
        logger.info(f'Time series plot of energy consumption seasonal residuals 1st difference is '
                    f'saved into {fig_path}.\n'
                    'The energy consumption seasonal residuals 1st difference time series look stationary.')

    def _plot_acf(self):
        fig_path = self.figure_path + 'acf_diff.png'
        tsaplots.plot_acf(
            self.model_data['Seasonal Residuals'].diff()[1:],
            title='Autocorrelation (ACF) of Consumption Cosine Fit Residuals 1st Difference'
        )
        plt.savefig(fig_path)
        plt.close()
        logger.info(f'ACF plot of energy consumption cosine fit residuals 1st difference is saved into {fig_path}.\n'
                    'ACF seems to decay after first 2 lags in each period, which might suggest MA(q=2).\n')

    def _plot_pacf(self):
        fig_path = self.figure_path + 'pacf_diff.png'
        tsaplots.plot_pacf(
            self.model_data['Seasonal Residuals'].diff()[1:],
            title='Partial Autocorrelation (PACF) of Consumption Seasonal Residuals 1st Difference'
        )
        plt.savefig(fig_path)
        plt.close()
        logger.info(f'PACF plot of energy consumption seasonal residuals 1st difference is saved into {fig_path}.\n'
                    'PPACF looks decaying after first 2 lags, which indicates a AR(p=2).\n')


# Please change the data path and figure path for your run.
# The data directory contains the dat file.
# The figure path gives the location that will save the analysis plots.
root = '/Users/ying/Documents/Data Science Test/'
data_path = root + 'energy.dat'
fig_path = root + 'figures/'
model = EnergyConsumptionModel(data_path, fig_path)
model.run()

